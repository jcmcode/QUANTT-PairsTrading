# Resources:


To learn git/github this youtube video will cover everything you need to know:

Git/Github: https://www.youtube.com/watch?v=RGOj5yH7evk

To get started with python this video will cover the basics to get started:

Python Course: https://www.youtube.com/watch?v=eWRfhZUzrAc

Moving Averages Example in Python: https://www.youtube.com/watch?v=YWnragvitFk


Pairs Trading videos:

https://www.youtube.com/watch?v=qnq1q0UONPE

https://www.youtube.com/watch?v=f73ItMWO4z8

Numpy/Pandas get started:

https://www.youtube.com/watch?v=VXU4LSAQDSc

https://www.youtube.com/watch?v=VXtjG_GzO7Q

Other Useful Resources:

https://www.youtube.com/watch?v=DjYZk8nrXVY


## Extra Videos/Resources Anyone thinks might be useful/Interesting Add Here:
